#!/bin/bash

echo "creating symbolic link to RNAseq tools directory"
ln -s ../../bin/ ./
echo "setting PATH"
wd=`pwd`
export PATH=".:$wd:$wd/bin:$PATH"
echo "making index directory"
mkdir index
echo "moving reference sequence and undesireables into index directory"
mv chrom3.fa index
mv Contaminants.fa index
echo "creating sample directories"
mkdir -p s_6 s_7 s_8
echo "moving sample fastq files into their respective directories"
mv s_6_* s_6
mv s_7_* s_7
mv s_8_* s_8
echo "creating symbolic links inside of sample directories"
cd s_6
ln -sf s_6_1_test.txt set1.fq
ln -sf s_6_2_test.txt set2.fq
cd ../s_7
ln -sf s_7_1_test.txt set1.fq
ln -sf s_7_2_test.txt set2.fq
cd ../s_8
ln -sf s_8_1_test.txt set1.fq
ln -sf s_8_2_test.txt set2.fq
cd ..
#
echo "making bowtie indices"
#
cd index
echo "building refseq index"
bowtie-build chrom3.fa refseq
echo "building undesireables index"
bowtie-build Contaminants.fa filter
echo "creating sybolic links"
ln -s chrom3.fa refseq.fa
ln -s Contaminants.fa filter.fa
cd ..
bash cmd
echo "finished"
